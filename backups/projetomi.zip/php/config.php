<?php

    $db_host = 'localhost';
    $db_user = 'root';
    $dbpassword = '';
    $dbname = 'projetomi';

    $conexao = new mysqli($db_host,$db_user,$dbpassword,$dbname);

    /*if($conexao -> connect_errno) {
        echo "Erro";
    }
    else
    {
        echo "Conexão feita com sucesso!";
    }
    */

?>