function logar() {

      var login = document.getElementById('login').value;
      var senha = document.getElementById('senha').value;

      if (login == "admin" && senha == "admin") {
        console.log("admin logado com sucesso!")
        location.href = "adm_salas.html";
      }

      else if (login == "usr" && senha == "usr") {
        console.log("usr logado com sucesso!")
        location.href = "usr_salas.html";
      }

      else {
        console.log("Usuario ou senha incorretos!")
      }

    }
    
window.addEventListener('DOMContentLoaded', function () {
      // Seleciona todos os parágrafos de tempo dentro das filas
      const timeParagraphs = document.querySelectorAll('.cronometro > p:last-child');
      // Para cada parágrafo, inicia um cronômetro se o texto for "00:00"
      timeParagraphs.forEach(function (p) {
        if (p.textContent.trim() === "00:00") {
          let seconds = 0;
          setInterval(function () {
            seconds++;
            const min = String(Math.floor(seconds / 60)).padStart(2, '0');
            const sec = String(seconds % 60).padStart(2, '0');
            p.textContent = `${min}:${sec}`;
          }, 1000);
        }
      });
    });

var imgAtual = "imagens/mao.png"
var imgAnterior = "imagens/close.png"

function trocar(){

  document.getElementById("mao").src = imgAtual;
  let aux = imgAtual;
  imgAtual = imgAnterior;
  imgAnterior = aux;
}

var imgAtual_adm = "imagens/clock.png"
var imgAnterior_adm = "imagens/close.png"

function trocar_adm(){

  document.getElementById("clock").src = imgAtual_adm;
  let aux = imgAtual_adm;
  imgAtual_adm = imgAnterior_adm;
  imgAnterior_adm = aux;
}